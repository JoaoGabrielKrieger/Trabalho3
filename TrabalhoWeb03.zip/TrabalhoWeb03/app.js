var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function() {

    if (this.readyState == 4) {
        if (this.status == 200) {
            var objetoRetornado = JSON.parse(this.responseText);

            console.log(objetoRetornado);

            var table = '';
            table += '<tr>';
            table += '<th>ID</th>';
            table += '<th>Nome</th>';
            table += '<th>Salário</th>';
            table += '<th>Idade</th>';
            table += '<th>Avatar</th>';
            table += '<tr>';


            $.each(objetoRetornado.data, function (key, value) {

                table += '<tr>';
                table += '<td>'+value.id+'</td>';
                table += '<td>'+value.employee_name+'</td>';
                table += '<td>'+value.employee_salary+'</td>';
                table += '<td>'+value.employee_age+'</td>';
                table += '<td><img src="'+value.profile_image+'"/></td>';
                table += '<tr>';
            });

            $('#listaDeConteudo').append(table);
        } else {
            alert(this.status);
        }
    }
}
xhttp.open("GET", "http://rest-api-employees.jmborges.site/api/v1/employees", true);
xhttp.setRequestHeader('Content-type', 'application/json');
xhttp.send();



$("#salvar").click(function() {
    var xhttp = new XMLHttpRequest();

    var novoEmpregado = {
        name: document.getElementById("name").value,
        salary: document.getElementById("salary").value,
        age: document.getElementById("number").value
    };
    xhttp.onreadystatechange = function() {
        debugger;
        if (this.readyState == 4) {
            if (this.status == 200) {
                var objetoRetornado = JSON.parse(this.responseText);
                var nome = objetoRetornado.data.name;
                alert("Empregado " + nome + " cadastrado com sucesso")
            } else {
                alert(this.status);
            }
        }
    }
    xhttp.open("POST", "http://rest-api-employees.jmborges.site/api/v1/create", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(novoEmpregado));
});


$("#excluirBotao").click(function() {
    debugger;
    var xhttp = new XMLHttpRequest();
    var deletaEmpregado = {
        id: document.getElementById("excluirFuncionario").value,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                var objetoRetornado = JSON.parse(this.responseText);
                var nome = objetoRetornado.data.name;
                alert("Empregado " + nome + " removido com sucesso");
            } else {
                alert(this.status);
            }

        }
    }
    xhttp.open("DELETE", "http://rest-api-employees.jmborges.site/api/v1/delete/2", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(deletaEmpregado));
});

$("#cancelar").click(function() {
    document.getElementById('form').reset();
});


$("#editar").click(function() {
    debugger;
    var xhttp = new XMLHttpRequest();
    var editarEmpregado = {
        id: document.getElementById("idEdicao").value,
        name: document.getElementById("nomeEdicao").value,
        salary: document.getElementById("salarioEdicao").value,
        age: document.getElementById("idadeEdicao").value
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                var objetoRetornado = JSON.parse(this.responseText);
                var id = objetoRetornado.data.id;
                alert("Mudou o campo:  " + id + " ");
            } else {
                alert(this.status);
            }
        }

    }
    xhttp.open("PUT", "	http://rest-api-employees.jmborges.site/api/v1/update/21", true);
    xhttp.setRequestHeader('Content-type', 'application/json');
    xhttp.send(JSON.stringify(editarEmpregado));
});